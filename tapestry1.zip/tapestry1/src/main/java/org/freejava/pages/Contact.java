package org.freejava.pages;

public class Contact
{

}
