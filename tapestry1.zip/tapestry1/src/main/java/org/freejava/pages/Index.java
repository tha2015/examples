package org.freejava.pages;

import java.util.Date;

/**
 * Start page of application tapestry1.
 */
public class Index
{
	public Date getCurrentTime() 
	{ 
		return new Date(); 
	}
}
